# Store

Access to Petstore orders

Find out more about our store: [http://swagger.io](http://swagger.io)

```ruby
store_controller = client.store
```

## Class Name

`StoreController`

## Methods

* [Get Inventory](../../doc/controllers/store.md#get-inventory)
* [Place Order](../../doc/controllers/store.md#place-order)
* [Get Order by Id](../../doc/controllers/store.md#get-order-by-id)
* [Delete Order](../../doc/controllers/store.md#delete-order)


# Get Inventory

Returns a map of status codes to quantities

```ruby
def get_inventory
```

## Server

`Server::DEFAULT1`

## Response Type

`Hash[String, Integer]`

## Example Usage

```ruby
result = store_controller.get_inventory
puts result
```

## Example Response

```
{
  "ordered": -1701012768,
  "approved": -1539485046,
  "placed": -2147313865,
  "test": -262249829,
  "pending": -1403561788,
  "available": 1386631487,
  "invalid": 2,
  "deliver": -1019515409,
  "delivered": 355966565
}
```


# Place Order

Place a new order in the store

:information_source: **Note** This endpoint does not require authentication.

```ruby
def place_order(id: nil,
                pet_id: nil,
                quantity: nil,
                ship_date: nil,
                order_status: OrderStatusEnum::APPROVED,
                complete: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Form, Optional | - |
| `pet_id` | `Integer` | Form, Optional | - |
| `quantity` | `Integer` | Form, Optional | - |
| `ship_date` | `DateTime` | Form, Optional | - |
| `order_status` | [`OrderStatusEnum`](../../doc/models/order-status-enum.md) | Form, Optional | Order Status<br><br>**Default**: `OrderStatusEnum::APPROVED` |
| `complete` | `TrueClass \| FalseClass` | Form, Optional | - |

## Server

`Server::DEFAULT1`

## Response Type

[`Order`](../../doc/models/order.md)

## Example Usage

```ruby
id = 10

pet_id = 198772

quantity = 7

ship_date = DateTimeHelper.from_rfc3339('05/31/2023 00:00:00')

order_status = OrderStatusEnum::APPROVED

complete = true

result = store_controller.place_order(
  id: id,
  pet_id: pet_id,
  quantity: quantity,
  ship_date: ship_date,
  order_status: order_status,
  complete: complete
)
puts result
```

## Example Response *(as JSON)*

```json
{
  "id": 10,
  "petId": 198772,
  "quantity": 7,
  "shipDate": "2023-05-31T00:00:00Z",
  "orderStatus": "approved",
  "complete": true
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 405 | Invalid input | `APIException` |


# Get Order by Id

For valid response try integer IDs with value <= 5 or > 10. Other values will generate exceptions.

:information_source: **Note** This endpoint does not require authentication.

```ruby
def get_order_by_id(order_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `order_id` | `Integer` | Template, Required | ID of order that needs to be fetched |

## Server

`Server::DEFAULT1`

## Response Type

[`Order`](../../doc/models/order.md)

## Example Usage

```ruby
order_id = 62

result = store_controller.get_order_by_id(order_id)
puts result
```

## Example Response *(as JSON)*

```json
{
  "id": 10,
  "petId": 198772,
  "quantity": 7,
  "shipDate": "2023-05-31T00:00:00Z",
  "orderStatus": "approved",
  "complete": true
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid ID supplied | `APIException` |
| 404 | Order not found | `APIException` |


# Delete Order

For valid response try integer IDs with value < 1000. Anything above 1000 or nonintegers will generate API errors

:information_source: **Note** This endpoint does not require authentication.

```ruby
def delete_order(order_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `order_id` | `Integer` | Template, Required | ID of the order that needs to be deleted |

## Server

`Server::DEFAULT1`

## Response Type

`void`

## Example Usage

```ruby
order_id = 62

store_controller.delete_order(order_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid ID supplied | `APIException` |
| 404 | Order not found | `APIException` |


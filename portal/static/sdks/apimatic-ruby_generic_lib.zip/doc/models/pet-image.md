
# Pet Image

## Structure

`PetImage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `Integer` | Optional | - |
| `type` | `String` | Optional | - |
| `message` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "code": 96,
  "type": "type8",
  "message": "message8"
}
```


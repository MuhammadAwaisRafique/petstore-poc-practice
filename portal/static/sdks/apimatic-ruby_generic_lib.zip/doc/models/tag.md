
# Tag

## Structure

`Tag`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | - |
| `name` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "id": 242,
  "name": "name8"
}
```


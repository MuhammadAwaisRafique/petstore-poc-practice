
# Pet by Category

## Structure

`PetByCategory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | - |
| `photo_urls` | `Array[String]` | Required | - |
| `id` | `Integer` | Optional | - |
| `category` | [`Category`](../../doc/models/category.md) | Required | - |
| `pet_status` | [`PetStatusEnum`](../../doc/models/pet-status-enum.md) | Optional | pet status in the store |

## Example (as JSON)

```json
{
  "name": "name6",
  "photoUrls": [
    "photoUrls1",
    "photoUrls2",
    "photoUrls3"
  ],
  "id": 10,
  "category": {
    "id": 1,
    "name": "Dogs"
  },
  "petStatus": "pending"
}
```


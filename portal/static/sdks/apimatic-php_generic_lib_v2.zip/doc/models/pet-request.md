
# Pet Request

## Structure

`PetRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `photoUrls` | `?(string[])` | Optional | - | getPhotoUrls(): ?array | setPhotoUrls(?array photoUrls): void |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `category` | [`?Category`](../../doc/models/category.md) | Optional | - | getCategory(): ?Category | setCategory(?Category category): void |
| `petStatus` | [`?string(PetStatusEnum)`](../../doc/models/pet-status-enum.md) | Optional | pet status in the store | getPetStatus(): ?string | setPetStatus(?string petStatus): void |
| `tags` | [`?(Tag[])`](../../doc/models/tag.md) | Optional | - | getTags(): ?array | setTags(?array tags): void |

## Example (as JSON)

```json
{
  "name": "Fluffy",
  "photoUrls": [
    "https://example.com/photo1.jpg",
    "https://example.com/photo2.jpg"
  ],
  "id": 10,
  "petStatus": "available",
  "tags": [
    {
      "id": 1,
      "name": "tag1"
    },
    {
      "id": 2,
      "name": "tag2"
    }
  ],
  "category": {
    "id": 232,
    "name": "name2"
  }
}
```



# Pet by Category

## Structure

`PetByCategory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | - | getName(): string | setName(string name): void |
| `photoUrls` | `string[]` | Required | - | getPhotoUrls(): array | setPhotoUrls(array photoUrls): void |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `category` | [`Category`](../../doc/models/category.md) | Required | - | getCategory(): Category | setCategory(Category category): void |
| `petStatus` | [`?string(PetStatusEnum)`](../../doc/models/pet-status-enum.md) | Optional | pet status in the store | getPetStatus(): ?string | setPetStatus(?string petStatus): void |

## Example (as JSON)

```json
{
  "name": "name6",
  "photoUrls": [
    "photoUrls1",
    "photoUrls2",
    "photoUrls3"
  ],
  "id": 10,
  "category": {
    "id": 1,
    "name": "Dogs"
  },
  "petStatus": "pending"
}
```


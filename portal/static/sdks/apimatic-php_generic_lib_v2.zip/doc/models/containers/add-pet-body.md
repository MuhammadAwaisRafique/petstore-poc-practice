
# Add Pet Body

## Data Type

`PetByCategory|PetByTag`

## Cases

| Type |
|  --- |
| [`PetByCategory`](../../../doc/models/pet-by-category.md) |
| [`PetByTag`](../../../doc/models/pet-by-tag.md) |



# Pet by Tag

## Structure

`PetByTag`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | - | getName(): string | setName(string name): void |
| `photoUrls` | `string[]` | Required | - | getPhotoUrls(): array | setPhotoUrls(array photoUrls): void |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `tags` | [`Tag[]`](../../doc/models/tag.md) | Required | - | getTags(): array | setTags(array tags): void |
| `petStatus` | [`?string(PetStatusEnum)`](../../doc/models/pet-status-enum.md) | Optional | pet status in the store | getPetStatus(): ?string | setPetStatus(?string petStatus): void |

## Example (as JSON)

```json
{
  "name": "Fluffy",
  "photoUrls": [
    "https://example.com/photo1.jpg",
    "https://example.com/photo2.jpg"
  ],
  "id": 10,
  "tags": [
    {
      "id": 1,
      "name": "tag1"
    },
    {
      "id": 2,
      "name": "tag2"
    }
  ],
  "petStatus": "available"
}
```



# Custom Header Signature



Documentation for accessing and setting credentials for api_key.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| api_key | `String` | - | `apiKey` | `getApiKey()` |



**Note:** Auth credentials can be set using `customHeaderAuthenticationCredentials` in the client builder and accessed through `getCustomHeaderAuthenticationCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```java
import io.apimatic.examples.APIMATICClient;
import io.apimatic.examples.authentication.CustomHeaderAuthenticationModel;

public class Program {
    public static void main(String[] args) {
        APIMATICClient client = new APIMATICClient.Builder()
            .customHeaderAuthenticationCredentials(new CustomHeaderAuthenticationModel.Builder(
                    "api_key"
                )
                .build())
            .build();
    }
}
```



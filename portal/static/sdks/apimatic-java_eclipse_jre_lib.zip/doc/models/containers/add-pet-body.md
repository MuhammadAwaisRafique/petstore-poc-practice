
# Add Pet Body

## Class Name

`AddPetBody`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`PetByCategory`](../../../doc/models/pet-by-category.md) | AddPetBody.fromPetByCategory(PetByCategory petByCategory) |
| [`PetByTag`](../../../doc/models/pet-by-tag.md) | AddPetBody.fromPetByTag(PetByTag petByTag) |


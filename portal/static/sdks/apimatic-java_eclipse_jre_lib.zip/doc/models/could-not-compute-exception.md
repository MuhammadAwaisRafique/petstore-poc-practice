
# Could Not Compute Exception

Is thrown when invalid input is given such as div by zero

## Structure

`CouldNotComputeException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ServerMessage` | `String` | Required | Represents the server's exception message | String getServerMessage() | setServerMessage(String serverMessage) |
| `ServerCode` | `int` | Required | Represents the server's error code | int getServerCode() | setServerCode(int serverCode) |

## Example (as JSON)

```json
{
  "ServerMessage": "ServerMessage4",
  "ServerCode": 24
}
```


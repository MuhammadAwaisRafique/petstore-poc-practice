
# Pet by Category

## Structure

`PetByCategory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | - | String getName() | setName(String name) |
| `PhotoUrls` | `List<String>` | Required | - | List<String> getPhotoUrls() | setPhotoUrls(List<String> photoUrls) |
| `Id` | `Long` | Optional | - | Long getId() | setId(Long id) |
| `Category` | [`Category`](../../doc/models/category.md) | Required | - | Category getCategory() | setCategory(Category category) |
| `PetStatus` | [`PetStatusEnum`](../../doc/models/pet-status-enum.md) | Optional | pet status in the store | PetStatusEnum getPetStatus() | setPetStatus(PetStatusEnum petStatus) |

## Example (as JSON)

```json
{
  "name": "name6",
  "photoUrls": [
    "photoUrls1",
    "photoUrls2",
    "photoUrls3"
  ],
  "id": 10,
  "category": {
    "id": 1,
    "name": "Dogs"
  },
  "petStatus": "pending"
}
```



# Pet Status Enum

pet status in the store

## Enumeration

`PetStatusEnum`

## Fields

| Name |
|  --- |
| `Available` |
| `Pending` |
| `Sold` |


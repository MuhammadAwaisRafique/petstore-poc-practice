
# Pet Image

## Structure

`PetImage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `number \| undefined` | Optional | - |
| `type` | `string \| undefined` | Optional | - |
| `message` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "code": 96,
  "type": "type8",
  "message": "message8"
}
```


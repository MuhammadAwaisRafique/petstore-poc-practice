
# Add Pet Body

## Class Name

`AddPetBody`

## Cases

| Type |
|  --- |
| [`PetByCategory`](../../../doc/models/pet-by-category.md) |
| [`PetByTag`](../../../doc/models/pet-by-tag.md) |


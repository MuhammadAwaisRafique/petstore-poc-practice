
# Could Not Compute Error

Is thrown when invalid input is given such as div by zero

## Structure

`CouldNotComputeError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `serverMessage` | `string` | Required | Represents the server's exception message |
| `serverCode` | `number` | Required | Represents the server's error code |

## Example (as JSON)

```json
{
  "ServerMessage": "ServerMessage4",
  "ServerCode": 24
}
```


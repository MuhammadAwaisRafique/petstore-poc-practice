
# Pet Request

## Structure

`PetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | - |
| `photoUrls` | `string[] \| undefined` | Optional | - |
| `id` | `bigint \| undefined` | Optional | - |
| `category` | [`Category \| undefined`](../../doc/models/category.md) | Optional | - |
| `petStatus` | [`PetStatusEnum \| undefined`](../../doc/models/pet-status-enum.md) | Optional | pet status in the store |
| `tags` | [`Tag[] \| undefined`](../../doc/models/tag.md) | Optional | - |

## Example (as JSON)

```json
{
  "name": "Fluffy",
  "photoUrls": [
    "https://example.com/photo1.jpg",
    "https://example.com/photo2.jpg"
  ],
  "id": 10,
  "petStatus": "available",
  "tags": [
    {
      "id": 1,
      "name": "tag1"
    },
    {
      "id": 2,
      "name": "tag2"
    }
  ],
  "category": {
    "id": 232,
    "name": "name2"
  }
}
```


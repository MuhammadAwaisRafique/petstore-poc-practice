
# Could Not Compute Exception

Is thrown when invalid input is given such as div by zero

## Structure

`CouldNotComputeException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ServerMessage` | `string` | Required | Represents the server's exception message |
| `ServerCode` | `int` | Required | Represents the server's error code |

## Example (as JSON)

```json
{
  "ServerMessage": "ServerMessage4",
  "ServerCode": 24
}
```


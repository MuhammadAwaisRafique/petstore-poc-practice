
# Pet Request

## Structure

`PetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | - |
| `PhotoUrls` | `List<string>` | Optional | - |
| `Id` | `long?` | Optional | - |
| `Category` | [`Category`](../../doc/models/category.md) | Optional | - |
| `PetStatus` | [`PetStatusEnum?`](../../doc/models/pet-status-enum.md) | Optional | pet status in the store |
| `Tags` | [`List<Tag>`](../../doc/models/tag.md) | Optional | - |

## Example (as JSON)

```json
{
  "name": "Fluffy",
  "photoUrls": [
    "https://example.com/photo1.jpg",
    "https://example.com/photo2.jpg"
  ],
  "id": 10,
  "petStatus": "available",
  "tags": [
    {
      "id": 1,
      "name": "tag1"
    },
    {
      "id": 2,
      "name": "tag2"
    }
  ],
  "category": {
    "id": 232,
    "name": "name2"
  }
}
```


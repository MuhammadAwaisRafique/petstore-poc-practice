# Pet

Everything about your Pets

Find out more: [http://swagger.io](http://swagger.io)

```csharp
PetController petController = client.PetController;
```

## Class Name

`PetController`

## Methods

* [Update Pet](../../doc/controllers/pet.md#update-pet)
* [Add Pet](../../doc/controllers/pet.md#add-pet)
* [Find Pets by Status](../../doc/controllers/pet.md#find-pets-by-status)
* [Find Pets by Tags](../../doc/controllers/pet.md#find-pets-by-tags)
* [Get Pet by Id](../../doc/controllers/pet.md#get-pet-by-id)
* [Update Pet With Form](../../doc/controllers/pet.md#update-pet-with-form)
* [Delete Pet](../../doc/controllers/pet.md#delete-pet)
* [Upload File](../../doc/controllers/pet.md#upload-file)


# Update Pet

Update an existing pet by Id

:information_source: **Note** This endpoint does not require authentication.

```csharp
UpdatePetAsync(
    Models.Pet body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Pet`](../../doc/models/pet.md) | Body, Required | Update an existent pet in the store |

## Response Type

[`Task<Models.Pet>`](../../doc/models/pet.md)

## Example Usage

```csharp
Pet body = new Pet
{
    Name = "doggie",
    PhotoUrls = new List<string>
    {
        "myphoto",
    },
    Id = 10L,
    PetStatus = PetStatusEnum.Sold,
};

try
{
    Pet result = await petController.UpdatePetAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "name": "Rex",
  "photoUrls": [
    "https://example.com/photo1.jpg",
    "https://example.com/photo2.jpg"
  ],
  "id": 123,
  "category": {
    "id": 1,
    "name": "Cats"
  },
  "tags": [
    {
      "id": 1,
      "name": "friendly"
    },
    {
      "id": 2,
      "name": "playful"
    }
  ],
  "petStatus": "available"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid ID supplied | `ApiException` |
| 404 | Pet not found | `ApiException` |
| 405 | Validation exception | `ApiException` |


# Add Pet

Add a new pet to the store

:information_source: **Note** This endpoint does not require authentication.

```csharp
AddPetAsync(
    AddPetBody body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AddPetBody`](../../doc/models/containers/add-pet-body.md) | Body, Required | This is a container for any-of cases. |

## Response Type

[`Task<Models.Pet>`](../../doc/models/pet.md)

## Example Usage

```csharp
AddPetBody body = AddPetBody.FromPetByCategory(
    new PetByCategory
    {
        Name = "name6",
        PhotoUrls = new List<string>
        {
            "photoUrls1",
            "photoUrls2",
            "photoUrls3",
        },
        Category = new Category
        {
            Id = 1L,
            Name = "Dogs",
        },
        Id = 10L,
    }
);

try
{
    Pet result = await petController.AddPetAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "name": "Rex",
  "photoUrls": [
    "https://example.com/photo1.jpg",
    "https://example.com/photo2.jpg"
  ],
  "id": 123,
  "category": {
    "id": 1,
    "name": "Dogs"
  },
  "tags": [
    {
      "id": 1,
      "name": "friendly"
    },
    {
      "id": 2,
      "name": "playful"
    }
  ],
  "petStatus": "available"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 405 | Invalid input | `ApiException` |


# Find Pets by Status

Multiple status values can be provided with comma separated strings

:information_source: **Note** This endpoint does not require authentication.

```csharp
FindPetsByStatusAsync(
    Models.StatusEnum? status = Models.StatusEnum.Available)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`StatusEnum?`](../../doc/models/status-enum.md) | Query, Optional | Status values that need to be considered for filter<br><br>**Default**: `StatusEnum.available` |

## Response Type

[`Task<List<Models.Pet>>`](../../doc/models/pet.md)

## Example Usage

```csharp
StatusEnum? status = StatusEnum.Available;
try
{
    List<Pet> result = await petController.FindPetsByStatusAsync(status);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
[
  {
    "id": 10,
    "name": "doggie",
    "photoUrls": [
      "photoUrls5",
      "photoUrls6"
    ],
    "category": {
      "id": 232,
      "name": "name2"
    },
    "tags": [
      {
        "id": 26,
        "name": "name0"
      }
    ],
    "petStatus": "sold"
  },
  {
    "id": 11,
    "name": "kitty",
    "photoUrls": [
      "photoUrls7",
      "photoUrls8"
    ],
    "category": {
      "id": 233,
      "name": "name3"
    },
    "tags": [
      {
        "id": 27,
        "name": "name1"
      }
    ],
    "petStatus": "available"
  }
]
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid status value | `ApiException` |


# Find Pets by Tags

Multiple tags can be provided with comma separated strings. Use tag1, tag2, tag3 for testing.

:information_source: **Note** This endpoint does not require authentication.

```csharp
FindPetsByTagsAsync(
    List<string> tags = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tags` | `List<string>` | Query, Optional | Tags to filter by |

## Response Type

[`Task<List<Models.Pet>>`](../../doc/models/pet.md)

## Example Usage

```csharp
try
{
    List<Pet> result = await petController.FindPetsByTagsAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
[
  {
    "id": 10,
    "name": "doggie",
    "photoUrls": [
      "photoUrls5",
      "photoUrls6"
    ],
    "category": {
      "id": 232,
      "name": "name2"
    },
    "tags": [
      {
        "id": 26,
        "name": "name0"
      }
    ],
    "petStatus": "sold"
  },
  {
    "id": 11,
    "name": "kitty",
    "photoUrls": [
      "photoUrls7",
      "photoUrls8"
    ],
    "category": {
      "id": 233,
      "name": "name3"
    },
    "tags": [
      {
        "id": 27,
        "name": "name1"
      }
    ],
    "petStatus": "available"
  }
]
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid tag value | `ApiException` |


# Get Pet by Id

Returns a single pet

```csharp
GetPetByIdAsync(
    long petId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `petId` | `long` | Template, Required | ID of pet to return |

## Response Type

[`Task<Models.Pet>`](../../doc/models/pet.md)

## Example Usage

```csharp
long petId = 152L;
try
{
    Pet result = await petController.GetPetByIdAsync(petId);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "name": "Rex",
  "photoUrls": [
    "https://example.com/photo1.jpg",
    "https://example.com/photo2.jpg"
  ],
  "id": 123,
  "category": {
    "id": 1,
    "name": "Dogs"
  },
  "tags": [
    {
      "id": 1,
      "name": "friendly"
    },
    {
      "id": 2,
      "name": "playful"
    }
  ],
  "petStatus": "available"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid ID supplied | `ApiException` |
| 404 | Pet not found | `ApiException` |


# Update Pet With Form

:information_source: **Note** This endpoint does not require authentication.

```csharp
UpdatePetWithFormAsync(
    long petId,
    string name = null,
    string status = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `petId` | `long` | Template, Required | ID of pet that needs to be updated |
| `name` | `string` | Query, Optional | Name of pet that needs to be updated |
| `status` | `string` | Query, Optional | Status of pet that needs to be updated |

## Response Type

`Task`

## Example Usage

```csharp
long petId = 152L;
try
{
    await petController.UpdatePetWithFormAsync(petId);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 405 | Invalid input | `ApiException` |


# Delete Pet

delete a pet

:information_source: **Note** This endpoint does not require authentication.

```csharp
DeletePetAsync(
    long petId,
    string apiKey = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `petId` | `long` | Template, Required | Pet id to delete |
| `apiKey` | `string` | Header, Optional | - |

## Response Type

`Task`

## Example Usage

```csharp
long petId = 152L;
try
{
    await petController.DeletePetAsync(petId);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid pet value | `ApiException` |


# Upload File

:information_source: **Note** This endpoint does not require authentication.

```csharp
UploadFileAsync(
    long petId,
    string additionalMetadata = null,
    FileStreamInfo body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `petId` | `long` | Template, Required | ID of pet to update |
| `additionalMetadata` | `string` | Query, Optional | Additional Metadata |
| `body` | `FileStreamInfo` | Form, Optional | - |

## Response Type

[`Task<Models.PetImage>`](../../doc/models/pet-image.md)

## Example Usage

```csharp
long petId = 152L;
try
{
    PetImage result = await petController.UploadFileAsync(petId);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "code": 200,
  "type": "unknown",
  "message": "additionalMetadata"
}
```


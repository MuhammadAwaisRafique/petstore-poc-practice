# Pet

Everything about your Pets

Find out more: [http://swagger.io](http://swagger.io)

```python
pet_controller = client.pet
```

## Class Name

`PetController`

## Methods

* [Update Pet](../../doc/controllers/pet.md#update-pet)
* [Add Pet](../../doc/controllers/pet.md#add-pet)
* [Find Pets by Status](../../doc/controllers/pet.md#find-pets-by-status)
* [Find Pets by Tags](../../doc/controllers/pet.md#find-pets-by-tags)
* [Get Pet by Id](../../doc/controllers/pet.md#get-pet-by-id)
* [Update Pet With Form](../../doc/controllers/pet.md#update-pet-with-form)
* [Delete Pet](../../doc/controllers/pet.md#delete-pet)
* [Upload File](../../doc/controllers/pet.md#upload-file)


# Update Pet

Update an existing pet by Id

:information_source: **Note** This endpoint does not require authentication.

```python
def update_pet(self,
              body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Pet`](../../doc/models/pet.md) | Body, Required | Update an existent pet in the store |

## Response Type

[`Pet`](../../doc/models/pet.md)

## Example Usage

```python
body = Pet(
    name='doggie',
    photo_urls=[
        'myphoto'
    ],
    id=10,
    pet_status=PetStatusEnum.SOLD
)

result = pet_controller.update_pet(body)
print(result)
```

## Example Response *(as JSON)*

```json
{
  "name": "Rex",
  "photoUrls": [
    "https://example.com/photo1.jpg",
    "https://example.com/photo2.jpg"
  ],
  "id": 123,
  "category": {
    "id": 1,
    "name": "Cats"
  },
  "tags": [
    {
      "id": 1,
      "name": "friendly"
    },
    {
      "id": 2,
      "name": "playful"
    }
  ],
  "petStatus": "available"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid ID supplied | `APIException` |
| 404 | Pet not found | `APIException` |
| 405 | Validation exception | `APIException` |


# Add Pet

Add a new pet to the store

:information_source: **Note** This endpoint does not require authentication.

```python
def add_pet(self,
           body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [PetByCategory](../../doc/models/pet-by-category.md) \| [PetByTag](../../doc/models/pet-by-tag.md) | Body, Required | This is a container for any-of cases. |

## Response Type

[`Pet`](../../doc/models/pet.md)

## Example Usage

```python
body = PetByCategory(
    name='name6',
    photo_urls=[
        'photoUrls1',
        'photoUrls2',
        'photoUrls3'
    ],
    category=Category(
        id=1,
        name='Dogs'
    ),
    id=10
)

result = pet_controller.add_pet(body)
print(result)
```

## Example Response *(as JSON)*

```json
{
  "name": "Rex",
  "photoUrls": [
    "https://example.com/photo1.jpg",
    "https://example.com/photo2.jpg"
  ],
  "id": 123,
  "category": {
    "id": 1,
    "name": "Dogs"
  },
  "tags": [
    {
      "id": 1,
      "name": "friendly"
    },
    {
      "id": 2,
      "name": "playful"
    }
  ],
  "petStatus": "available"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 405 | Invalid input | `APIException` |


# Find Pets by Status

Multiple status values can be provided with comma separated strings

:information_source: **Note** This endpoint does not require authentication.

```python
def find_pets_by_status(self,
                       status="available")
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`StatusEnum`](../../doc/models/status-enum.md) | Query, Optional | Status values that need to be considered for filter<br><br>**Default**: `"available"` |

## Response Type

[`List[Pet]`](../../doc/models/pet.md)

## Example Usage

```python
status = StatusEnum.AVAILABLE

result = pet_controller.find_pets_by_status(
    status=status
)
print(result)
```

## Example Response *(as JSON)*

```json
[
  {
    "id": 10,
    "name": "doggie",
    "photoUrls": [
      "photoUrls5",
      "photoUrls6"
    ],
    "category": {
      "id": 232,
      "name": "name2"
    },
    "tags": [
      {
        "id": 26,
        "name": "name0"
      }
    ],
    "petStatus": "sold"
  },
  {
    "id": 11,
    "name": "kitty",
    "photoUrls": [
      "photoUrls7",
      "photoUrls8"
    ],
    "category": {
      "id": 233,
      "name": "name3"
    },
    "tags": [
      {
        "id": 27,
        "name": "name1"
      }
    ],
    "petStatus": "available"
  }
]
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid status value | `APIException` |


# Find Pets by Tags

Multiple tags can be provided with comma separated strings. Use tag1, tag2, tag3 for testing.

:information_source: **Note** This endpoint does not require authentication.

```python
def find_pets_by_tags(self,
                     tags=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tags` | `List[str]` | Query, Optional | Tags to filter by |

## Response Type

[`List[Pet]`](../../doc/models/pet.md)

## Example Usage

```python
result = pet_controller.find_pets_by_tags()
print(result)
```

## Example Response *(as JSON)*

```json
[
  {
    "id": 10,
    "name": "doggie",
    "photoUrls": [
      "photoUrls5",
      "photoUrls6"
    ],
    "category": {
      "id": 232,
      "name": "name2"
    },
    "tags": [
      {
        "id": 26,
        "name": "name0"
      }
    ],
    "petStatus": "sold"
  },
  {
    "id": 11,
    "name": "kitty",
    "photoUrls": [
      "photoUrls7",
      "photoUrls8"
    ],
    "category": {
      "id": 233,
      "name": "name3"
    },
    "tags": [
      {
        "id": 27,
        "name": "name1"
      }
    ],
    "petStatus": "available"
  }
]
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid tag value | `APIException` |


# Get Pet by Id

Returns a single pet

```python
def get_pet_by_id(self,
                 pet_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pet_id` | `int` | Template, Required | ID of pet to return |

## Response Type

[`Pet`](../../doc/models/pet.md)

## Example Usage

```python
pet_id = 152

result = pet_controller.get_pet_by_id(pet_id)
print(result)
```

## Example Response *(as JSON)*

```json
{
  "name": "Rex",
  "photoUrls": [
    "https://example.com/photo1.jpg",
    "https://example.com/photo2.jpg"
  ],
  "id": 123,
  "category": {
    "id": 1,
    "name": "Dogs"
  },
  "tags": [
    {
      "id": 1,
      "name": "friendly"
    },
    {
      "id": 2,
      "name": "playful"
    }
  ],
  "petStatus": "available"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid ID supplied | `APIException` |
| 404 | Pet not found | `APIException` |


# Update Pet With Form

:information_source: **Note** This endpoint does not require authentication.

```python
def update_pet_with_form(self,
                        pet_id,
                        name=None,
                        status=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pet_id` | `int` | Template, Required | ID of pet that needs to be updated |
| `name` | `str` | Query, Optional | Name of pet that needs to be updated |
| `status` | `str` | Query, Optional | Status of pet that needs to be updated |

## Response Type

`void`

## Example Usage

```python
pet_id = 152

pet_controller.update_pet_with_form(pet_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 405 | Invalid input | `APIException` |


# Delete Pet

delete a pet

:information_source: **Note** This endpoint does not require authentication.

```python
def delete_pet(self,
              pet_id,
              api_key=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pet_id` | `int` | Template, Required | Pet id to delete |
| `api_key` | `str` | Header, Optional | - |

## Response Type

`void`

## Example Usage

```python
pet_id = 152

pet_controller.delete_pet(pet_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid pet value | `APIException` |


# Upload File

:information_source: **Note** This endpoint does not require authentication.

```python
def upload_file(self,
               pet_id,
               additional_metadata=None,
               body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pet_id` | `int` | Template, Required | ID of pet to update |
| `additional_metadata` | `str` | Query, Optional | Additional Metadata |
| `body` | `typing.BinaryIO` | Form, Optional | - |

## Response Type

[`PetImage`](../../doc/models/pet-image.md)

## Example Usage

```python
pet_id = 152

result = pet_controller.upload_file(pet_id)
print(result)
```

## Example Response *(as JSON)*

```json
{
  "code": 200,
  "type": "unknown",
  "message": "additionalMetadata"
}
```


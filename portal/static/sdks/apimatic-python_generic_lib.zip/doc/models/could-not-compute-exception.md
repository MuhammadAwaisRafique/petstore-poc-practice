
# Could Not Compute Exception

Is thrown when invalid input is given such as div by zero

## Structure

`CouldNotComputeException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `server_message` | `str` | Required | Represents the server's exception message |
| `server_code` | `int` | Required | Represents the server's error code |

## Example (as JSON)

```json
{
  "ServerMessage": "ServerMessage4",
  "ServerCode": 24
}
```



# Pet Image

## Structure

`PetImage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `int` | Optional | - |
| `mtype` | `str` | Optional | - |
| `message` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "code": 96,
  "type": "type8",
  "message": "message8"
}
```


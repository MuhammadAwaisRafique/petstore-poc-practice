
# Address

## Structure

`Address`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `street` | `str` | Optional | - |
| `city` | `str` | Optional | - |
| `state` | `str` | Optional | - |
| `zip` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "street": "437 Lytton",
  "city": "Palo Alto",
  "state": "CA",
  "zip": "94301"
}
```


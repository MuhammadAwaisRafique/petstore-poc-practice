
# Tag

## Structure

`Tag`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `name` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "id": 242,
  "name": "name8"
}
```


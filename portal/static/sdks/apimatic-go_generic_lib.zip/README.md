
# Getting Started with APIMATIC

## Introduction

Simple calculator API hosted on APIMATIC

Find out more about Swagger: [http://swagger.io](http://swagger.io)

### Requirements

The SDK requires **Go version 1.18 or above**.

## Building

### Install Dependencies

Resolve all the SDK dependencies, using the `go get` command.

## Installation

The following section explains how to use the apimatic library in a new project.

### 1. Add SDK as a Dependency to the Application

- Add the following lines to your application's `go.mod` file:

```go
replace apimatic => ".\\apimatic-go_generic_lib" // local path to the SDK

require apimatic v0.0.0
```

- Resolve the dependencies in the updated `go.mod` file, using the `go get` command.

## Test the SDK

`Go Testing` is used as the testing framework. To run the unit tests of the SDK, navigate to the root directory of the SDK and run the following command in the terminal:

```bash
$ go test
```

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | `Environment` | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| customHeaderAuthenticationCredentials | [`CustomHeaderAuthenticationCredentials`](doc/auth/custom-header-signature.md) | The Credentials Setter for Custom Header Signature |

The API client can be initialized as follows:

```go
package main

import (
    "apimatic"
)

func main() {
    client := apimatic.NewClient(
    apimatic.CreateConfiguration(
            apimatic.WithHttpConfiguration(
                apimatic.CreateHttpConfiguration(
                    apimatic.WithTimeout(0),
                ),
            ),
            apimatic.WithEnvironment(apimatic.PRODUCTION),
            apimatic.WithCustomHeaderAuthenticationCredentials(
                apimatic.NewCustomHeaderAuthenticationCredentials("api_key"),
            ),
        ),
    )
}
```

## Authorization

This API uses the following authentication schemes.

* [`api_key (Custom Header Signature)`](doc/auth/custom-header-signature.md)

## List of APIs

* [Simple Calculator](doc/controllers/simple-calculator.md)
* [Pet](doc/controllers/pet.md)
* [Store](doc/controllers/store.md)
* [User](doc/controllers/user.md)

## SDK Infrastructure

### Configuration

* [HttpConfiguration](doc/http-configuration.md)
* [RetryConfiguration](doc/retry-configuration.md)

### Utilities

* [ApiResponse](doc/api-response.md)


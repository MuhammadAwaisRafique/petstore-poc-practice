
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `0` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`apimaticRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `apimatic.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "apimatic"
    "net/http"
)

func main() {
    httpConfiguration := apimatic.CreateHttpConfiguration(
        apimatic.WithTimeout(0),
        apimatic.WithTransport(http.DefaultTransport),
        apimatic.WithRetryConfiguration(apimatic.DefaultRetryConfiguration()),
    )
}
```


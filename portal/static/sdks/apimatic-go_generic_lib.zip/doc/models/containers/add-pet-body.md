
# Add Pet Body

## Class Name

`AddPetBody`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`models.PetByCategory`](../../../doc/models/pet-by-category.md) | models.AddPetBodyContainer.FromPetByCategory(models.PetByCategory petByCategory) |
| [`models.PetByTag`](../../../doc/models/pet-by-tag.md) | models.AddPetBodyContainer.FromPetByTag(models.PetByTag petByTag) |


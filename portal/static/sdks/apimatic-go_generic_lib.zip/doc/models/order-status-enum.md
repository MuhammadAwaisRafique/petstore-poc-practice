
# Order Status Enum

Order Status

## Enumeration

`OrderStatusEnum`

## Fields

| Name |
|  --- |
| `PLACED` |
| `APPROVED` |
| `DELIVERED` |


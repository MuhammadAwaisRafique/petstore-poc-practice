
# Pet by Tag

## Structure

`PetByTag`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | - |
| `PhotoUrls` | `[]string` | Required | - |
| `Id` | `*int64` | Optional | - |
| `Tags` | [`[]models.Tag`](../../doc/models/tag.md) | Required | - |
| `PetStatus` | [`*models.PetStatusEnum`](../../doc/models/pet-status-enum.md) | Optional | pet status in the store |

## Example (as JSON)

```json
{
  "name": "Fluffy",
  "photoUrls": [
    "https://example.com/photo1.jpg",
    "https://example.com/photo2.jpg"
  ],
  "id": 10,
  "tags": [
    {
      "id": 1,
      "name": "tag1"
    },
    {
      "id": 2,
      "name": "tag2"
    }
  ],
  "petStatus": "available"
}
```


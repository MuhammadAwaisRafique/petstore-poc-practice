
# Tag

## Structure

`Tag`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `*int64` | Optional | - |
| `Name` | `*string` | Optional | - |

## Example (as JSON)

```json
{
  "id": 242,
  "name": "name8"
}
```


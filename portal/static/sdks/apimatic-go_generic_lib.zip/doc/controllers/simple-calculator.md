# Simple Calculator

```go
simpleCalculatorController := client.SimpleCalculatorController()
```

## Class Name

`SimpleCalculatorController`


# Calculate

Calculates the expression using the specified operation.

:information_source: **Note** This endpoint does not require authentication.

```go
Calculate(
    ctx context.Context,
    operation models.OperationTypeEnum,
    x float64,
    y float64) (
    models.ApiResponse[float64],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `operation` | [`models.OperationTypeEnum`](../../doc/models/operation-type-enum.md) | Template, Required | The operator to apply on the variables |
| `x` | `float64` | Query, Required | The LHS value |
| `y` | `float64` | Query, Required | The RHS value |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type float64.

## Example Usage

```go
ctx := context.Background()

operation := models.OperationTypeEnum_MULTIPLY

x := float64(222.14)

y := float64(165.14)

apiResponse, err := simpleCalculatorController.Calculate(ctx, operation, x, y)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.CouldNotCompute:
            log.Fatalln("CouldNotComputeException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 412 | Could not compute the requested calculation | [`CouldNotComputeException`](../../doc/models/could-not-compute-exception.md) |


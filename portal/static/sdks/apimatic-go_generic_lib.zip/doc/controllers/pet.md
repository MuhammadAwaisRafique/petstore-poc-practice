# Pet

Everything about your Pets

Find out more: [http://swagger.io](http://swagger.io)

```go
petController := client.PetController()
```

## Class Name

`PetController`

## Methods

* [Update Pet](../../doc/controllers/pet.md#update-pet)
* [Add Pet](../../doc/controllers/pet.md#add-pet)
* [Find Pets by Status](../../doc/controllers/pet.md#find-pets-by-status)
* [Find Pets by Tags](../../doc/controllers/pet.md#find-pets-by-tags)
* [Get Pet by Id](../../doc/controllers/pet.md#get-pet-by-id)
* [Update Pet With Form](../../doc/controllers/pet.md#update-pet-with-form)
* [Delete Pet](../../doc/controllers/pet.md#delete-pet)
* [Upload File](../../doc/controllers/pet.md#upload-file)


# Update Pet

Update an existing pet by Id

:information_source: **Note** This endpoint does not require authentication.

```go
UpdatePet(
    ctx context.Context,
    body models.Pet) (
    models.ApiResponse[models.Pet],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.Pet`](../../doc/models/pet.md) | Body, Required | Update an existent pet in the store |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.Pet](../../doc/models/pet.md).

## Example Usage

```go
ctx := context.Background()

body := models.Pet{
    Name:                 "doggie",
    PhotoUrls:            []string{
        "myphoto",
    },
    Id:                   models.ToPointer(int64(10)),
    PetStatus:            models.ToPointer(models.PetStatusEnum_SOLD),
}

apiResponse, err := petController.UpdatePet(ctx, body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "name": "Rex",
  "photoUrls": [
    "https://example.com/photo1.jpg",
    "https://example.com/photo2.jpg"
  ],
  "id": 123,
  "category": {
    "id": 1,
    "name": "Cats"
  },
  "tags": [
    {
      "id": 1,
      "name": "friendly"
    },
    {
      "id": 2,
      "name": "playful"
    }
  ],
  "petStatus": "available"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid ID supplied | `ApiError` |
| 404 | Pet not found | `ApiError` |
| 405 | Validation exception | `ApiError` |


# Add Pet

Add a new pet to the store

:information_source: **Note** This endpoint does not require authentication.

```go
AddPet(
    ctx context.Context,
    body models.AddPetBody) (
    models.ApiResponse[models.Pet],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.AddPetBody`](../../doc/models/containers/add-pet-body.md) | Body, Required | This is a container for any-of cases. |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.Pet](../../doc/models/pet.md).

## Example Usage

```go
ctx := context.Background()

body := models.AddPetBodyContainer.FromPetByCategory(models.PetByCategory{
    Name:                 "name6",
    PhotoUrls:            []string{
        "photoUrls1",
        "photoUrls2",
        "photoUrls3",
    },
    Id:                   models.ToPointer(int64(10)),
    Category:             models.Category{
        Id:                   models.ToPointer(int64(1)),
        Name:                 models.ToPointer("Dogs"),
    },
})

apiResponse, err := petController.AddPet(ctx, body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "name": "Rex",
  "photoUrls": [
    "https://example.com/photo1.jpg",
    "https://example.com/photo2.jpg"
  ],
  "id": 123,
  "category": {
    "id": 1,
    "name": "Dogs"
  },
  "tags": [
    {
      "id": 1,
      "name": "friendly"
    },
    {
      "id": 2,
      "name": "playful"
    }
  ],
  "petStatus": "available"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 405 | Invalid input | `ApiError` |


# Find Pets by Status

Multiple status values can be provided with comma separated strings

:information_source: **Note** This endpoint does not require authentication.

```go
FindPetsByStatus(
    ctx context.Context,
    status *models.StatusEnum) (
    models.ApiResponse[[]models.Pet],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`*models.StatusEnum`](../../doc/models/status-enum.md) | Query, Optional | Status values that need to be considered for filter<br><br>**Default**: `"available"` |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [[]models.Pet](../../doc/models/pet.md).

## Example Usage

```go
ctx := context.Background()

status := models.StatusEnum_AVAILABLE

apiResponse, err := petController.FindPetsByStatus(ctx, &status)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
[
  {
    "id": 10,
    "name": "doggie",
    "photoUrls": [
      "photoUrls5",
      "photoUrls6"
    ],
    "category": {
      "id": 232,
      "name": "name2"
    },
    "tags": [
      {
        "id": 26,
        "name": "name0"
      }
    ],
    "petStatus": "sold"
  },
  {
    "id": 11,
    "name": "kitty",
    "photoUrls": [
      "photoUrls7",
      "photoUrls8"
    ],
    "category": {
      "id": 233,
      "name": "name3"
    },
    "tags": [
      {
        "id": 27,
        "name": "name1"
      }
    ],
    "petStatus": "available"
  }
]
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid status value | `ApiError` |


# Find Pets by Tags

Multiple tags can be provided with comma separated strings. Use tag1, tag2, tag3 for testing.

:information_source: **Note** This endpoint does not require authentication.

```go
FindPetsByTags(
    ctx context.Context,
    tags []string) (
    models.ApiResponse[[]models.Pet],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tags` | `[]string` | Query, Optional | Tags to filter by |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [[]models.Pet](../../doc/models/pet.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := petController.FindPetsByTags(ctx, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
[
  {
    "id": 10,
    "name": "doggie",
    "photoUrls": [
      "photoUrls5",
      "photoUrls6"
    ],
    "category": {
      "id": 232,
      "name": "name2"
    },
    "tags": [
      {
        "id": 26,
        "name": "name0"
      }
    ],
    "petStatus": "sold"
  },
  {
    "id": 11,
    "name": "kitty",
    "photoUrls": [
      "photoUrls7",
      "photoUrls8"
    ],
    "category": {
      "id": 233,
      "name": "name3"
    },
    "tags": [
      {
        "id": 27,
        "name": "name1"
      }
    ],
    "petStatus": "available"
  }
]
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid tag value | `ApiError` |


# Get Pet by Id

Returns a single pet

```go
GetPetById(
    ctx context.Context,
    petId int64) (
    models.ApiResponse[models.Pet],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `petId` | `int64` | Template, Required | ID of pet to return |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.Pet](../../doc/models/pet.md).

## Example Usage

```go
ctx := context.Background()

petId := int64(152)

apiResponse, err := petController.GetPetById(ctx, petId)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "name": "Rex",
  "photoUrls": [
    "https://example.com/photo1.jpg",
    "https://example.com/photo2.jpg"
  ],
  "id": 123,
  "category": {
    "id": 1,
    "name": "Dogs"
  },
  "tags": [
    {
      "id": 1,
      "name": "friendly"
    },
    {
      "id": 2,
      "name": "playful"
    }
  ],
  "petStatus": "available"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid ID supplied | `ApiError` |
| 404 | Pet not found | `ApiError` |


# Update Pet With Form

:information_source: **Note** This endpoint does not require authentication.

```go
UpdatePetWithForm(
    ctx context.Context,
    petId int64,
    name *string,
    status *string) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `petId` | `int64` | Template, Required | ID of pet that needs to be updated |
| `name` | `*string` | Query, Optional | Name of pet that needs to be updated |
| `status` | `*string` | Query, Optional | Status of pet that needs to be updated |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

petId := int64(152)

resp, err := petController.UpdatePetWithForm(ctx, petId, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 405 | Invalid input | `ApiError` |


# Delete Pet

delete a pet

:information_source: **Note** This endpoint does not require authentication.

```go
DeletePet(
    ctx context.Context,
    petId int64,
    apiKey *string) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `petId` | `int64` | Template, Required | Pet id to delete |
| `apiKey` | `*string` | Header, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

petId := int64(152)

resp, err := petController.DeletePet(ctx, petId, nil)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid pet value | `ApiError` |


# Upload File

:information_source: **Note** This endpoint does not require authentication.

```go
UploadFile(
    ctx context.Context,
    petId int64,
    additionalMetadata *string,
    body *models.FileWrapper) (
    models.ApiResponse[models.PetImage],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `petId` | `int64` | Template, Required | ID of pet to update |
| `additionalMetadata` | `*string` | Query, Optional | Additional Metadata |
| `body` | `*models.FileWrapper` | Form, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PetImage](../../doc/models/pet-image.md).

## Example Usage

```go
ctx := context.Background()

petId := int64(152)

apiResponse, err := petController.UploadFile(ctx, petId, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "code": 200,
  "type": "unknown",
  "message": "additionalMetadata"
}
```


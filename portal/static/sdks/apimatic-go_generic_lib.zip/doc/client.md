
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | `Environment` | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| customHeaderAuthenticationCredentials | [`CustomHeaderAuthenticationCredentials`](auth/custom-header-signature.md) | The Credentials Setter for Custom Header Signature |

The API client can be initialized as follows:

```go
package main

import (
    "apimatic"
)

func main() {
    client := apimatic.NewClient(
    apimatic.CreateConfiguration(
            apimatic.WithHttpConfiguration(
                apimatic.CreateHttpConfiguration(
                    apimatic.WithTimeout(0),
                ),
            ),
            apimatic.WithEnvironment(apimatic.PRODUCTION),
            apimatic.WithCustomHeaderAuthenticationCredentials(
                apimatic.NewCustomHeaderAuthenticationCredentials("api_key"),
            ),
        ),
    )
}
```

## APIMATIC Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| SimpleCalculatorController() | Gets SimpleCalculatorController |
| PetController() | Gets PetController |
| StoreController() | Gets StoreController |
| UserController() | Gets UserController |

